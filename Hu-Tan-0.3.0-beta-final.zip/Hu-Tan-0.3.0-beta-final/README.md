# Hu Tan 0.3.0-beta

**Hu Tan** بوت Messenger عربي Modular — المطور: **Rin Il**.

## الهوية

- الاسم: Hu Tan
- المطور: Rin Il
- الإصدار: 0.3.0-beta
- اللغة: العربية
- البادئة: `.`
- Hu Tan تتحدث عن نفسها بصيغة المؤنث.
- المستخدمون يُخاطَبون بصيغة المذكر المفرد المحايدة، من دون افتراض جنسهم.

## التشغيل في Termux

```bash
git clone <رابط-المستودع>
cd Hu-Tan
npm install
npm start
```

أو لتشغيل الإعداد يدويًا:

```bash
npm run setup
```

في أول إعداد، يستطيع Hu Tan قراءة `config/EDIT_ME.json` للحصول على `groupID` و`adminID` المجهزين مسبقًا.

## إعداد GitHub

الملف القابل للتحرير داخل المستودع هو:

```text
config/EDIT_ME.json
```

ضع فيه:

```json
{
  "adminID": "ضع_ID_المدير_هنا",
  "groupID": "ضع_ID_الغروب_هنا",
  "appStatePath": "data/appstate.json",
  "ai": {
    "enabled": false,
    "url": "",
    "apiKey": "",
    "model": ""
  }
}
```

بعد ذلك شغّل:

```bash
npm run setup
```

**لا تضع AppState الحقيقي داخل GitHub.** يوضع محليًا في `data/appstate.json`، وهو مستبعد من Git بواسطة `.gitignore`. كما لا تضع مفتاح AI الحقيقي في `EDIT_ME.json` إذا كان المستودع عامًا.

## الميزات

نظام أوامر Modular، إدارة الغروب، ترحيب الأعضاء، رسالة تعريف أول تشغيل، XP وRank، ترتيب، اقتصاد ومحفظة وبنك وتحويلات وسجل معاملات، وظائف ويومية، مهام يومية، ألعاب عربية، عداد رسائل وأوامر، AI مع Reply مؤقت وذاكرة لكل غروب، Anti-Spam وCooldown، منع تكرار الأحداث، وحفظ محلي ذري.

## بنية Messenger

يستخدم Hu Tan:

```text
@lazyneoaz/metachat@1.2.2
```

طبقة Messenger معزولة في `src/services/messenger.js`، بينما منطق البوت نفسه مستقل عن المكتبة. هذا يسهل استبدال طبقة الاتصال مستقبلًا من دون إعادة كتابة الأوامر.

## حماية التكرار

Hu Tan يمنع إعادة معالجة الحدث نفسه عبر `messageID/eventID`. وإذا لم يحتوي الحدث على معرّف، يستخدم بصمة `senderID + threadID + body` لمدة قصيرة. كما يمنع استقبال رسائل الحساب نفسه عندما تكون معلومات الحدث متاحة.

## الاختبارات

```bash
npm test
```

يشمل الاختبار Syntax، تحميل جميع الأوامر، اكتشاف تعارض الأسماء، الاقتصاد، المهام، Reply TTL، قاعدة البيانات، rate limits، وقاعدة منع تكرار الأحداث.

## بيانات خاصة

لا ترفع إلى GitHub:

```text
config/config.json
data/appstate.json
data/database.json
.env
```

الملفات النموذجية الآمنة التي يجب رفعها هي:

```text
config/EDIT_ME.json
config/config.example.json
data/appstate.example.json
```

واجهة Messenger المستخدمة غير رسمية وتعتمد على جلسة حساب Facebook. حصر البوت في غروب واحد وتقليل النشاط غير الضروري لا يضمن منع تقييد الحساب من Meta.
