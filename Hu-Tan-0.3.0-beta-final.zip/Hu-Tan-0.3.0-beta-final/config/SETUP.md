# إعداد Hu Tan

## القيم التي يمكن تجهيزها داخل GitHub

عدّل:

```text
config/EDIT_ME.json
```

وضع فيه `adminID` و`groupID` فقط إذا كان ذلك مناسبًا لمستودعك.

## AppState

ضع AppState الفعلي محليًا فقط في:

```text
data/appstate.json
```

لا تضعه في GitHub. `.gitignore` يمنع تتبعه.

## AI

يمكن ترك إعداد AI فارغًا في `EDIT_ME.json` ثم إدخاله أثناء `npm run setup`. مفتاح API الفعلي يبقى محليًا داخل `config/config.json`، وهو مستبعد من Git.
