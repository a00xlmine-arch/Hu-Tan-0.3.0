'use strict';

const fs = require('fs');
const path = require('path');
const readline = require('readline');

const ROOT = __dirname;
const CONFIG_DIR = path.join(ROOT, 'config');
const DATA_DIR = path.join(ROOT, 'data');
const CONFIG_PATH = path.join(CONFIG_DIR, 'config.json');
const EDIT_ME_PATH = path.join(CONFIG_DIR, 'EDIT_ME.json');

fs.mkdirSync(CONFIG_DIR, { recursive: true });
fs.mkdirSync(DATA_DIR, { recursive: true });

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

function ask(question) {
  return new Promise((resolve) => rl.question(question, (answer) => resolve(answer.trim())));
}

function askSecret(question) {
  return new Promise((resolve) => {
    if (!process.stdin.isTTY) return rl.question(question, (answer) => resolve(answer.trim()));

    const stdin = process.stdin;
    const oldRaw = stdin.isRaw;
    let value = '';

    const onData = (chunk) => {
      for (const ch of String(chunk)) {
        if (ch === '\r' || ch === '\n') {
          try { stdin.setRawMode(oldRaw || false); } catch (_) {}
          stdin.pause();
          stdin.off('data', onData);
          process.stdout.write('\n');
          resolve(value.trim());
          return;
        }
        if (ch === '\u0003') {
          try { stdin.setRawMode(oldRaw || false); } catch (_) {}
          stdin.pause();
          stdin.off('data', onData);
          process.stdout.write('\n');
          resolve('');
          return;
        }
        if (ch === '\u007f') {
          if (value.length) {
            value = value.slice(0, -1);
            process.stdout.write('\b \b');
          }
          continue;
        }
        value += ch;
        process.stdout.write('*');
      }
    };

    try { stdin.setRawMode(true); } catch (_) {}
    stdin.resume();
    stdin.on('data', onData);
  });
}

function readEditMe() {
  if (!fs.existsSync(EDIT_ME_PATH)) return {};
  try {
    const value = JSON.parse(fs.readFileSync(EDIT_ME_PATH, 'utf8').replace(/^\uFEFF/, ''));
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  } catch (_) {
    return {};
  }
}

function normalizeAppStatePath(value) {
  const raw = String(value || 'data/appstate.json').replace(/\\/g, '/').trim() || 'data/appstate.json';
  const normalized = path.posix.normalize(raw);
  if (normalized.startsWith('/') || normalized === '..' || normalized.startsWith('../') || normalized.includes('/../')) {
    throw new Error('مسار AppState يجب أن يكون داخل المشروع.');
  }
  if (!normalized.startsWith('data/')) throw new Error('مسار AppState يجب أن يبدأ بـ data/.');
  if (!normalized.endsWith('.json')) throw new Error('مسار AppState يجب أن ينتهي بـ .json.');
  return normalized;
}

function parseAppState(raw) {
  let parsed;
  try {
    parsed = JSON.parse(String(raw).replace(/^\uFEFF/, '').trim());
  } catch (error) {
    throw new Error(`تعذر تحليل AppState كـ JSON: ${error.message}`);
  }

  if (!Array.isArray(parsed) || parsed.length === 0) {
    throw new Error('AppState يجب أن يكون مصفوفة JSON غير فارغة.');
  }

  if (!parsed.every((item) => item && typeof item === 'object' && !Array.isArray(item))) {
    throw new Error('كل عنصر في AppState يجب أن يكون كائن JSON.');
  }

  return parsed;
}

function parseYesNo(value, fallback = true) {
  const normalized = String(value || '').trim().toLowerCase();
  if (!normalized) return fallback;
  return !['لا', 'no', 'n', '0', 'false'].includes(normalized);
}

function secureWrite(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600 });
  try { fs.chmodSync(filePath, 0o600); } catch (_) {}
}

function readExistingAppState(filePath) {
  if (!fs.existsSync(filePath)) return null;
  try {
    return parseAppState(fs.readFileSync(filePath, 'utf8'));
  } catch (_) {
    return null;
  }
}

async function getAppState(appStatePath) {
  const existing = readExistingAppState(appStatePath);
  if (existing) {
    const useExisting = parseYesNo(await ask('وُجد AppState محفوظ. هل تريد استخدامه؟ [نعم/لا]: '), true);
    if (useExisting) return existing;
  }

  while (true) {
    try {
      const source = await ask(`مسار ملف AppState (Enter = ${appStatePath}): `);
      const chosen = source || appStatePath;
      const filePath = path.resolve(ROOT, chosen);
      if (!filePath.startsWith(`${ROOT}${path.sep}`) && filePath !== ROOT) throw new Error('المسار يجب أن يكون داخل المشروع.');
      if (!fs.existsSync(filePath)) throw new Error(`الملف غير موجود: ${filePath}`);
      return parseAppState(fs.readFileSync(filePath, 'utf8'));
    } catch (error) {
      console.log(`✗ ${error.message}\n`);
    }
  }
}

async function askNumeric(label, preset = '', allowEmpty = false) {
  if (/^\d+$/.test(String(preset))) return String(preset);
  while (true) {
    const value = await ask(label);
    if (allowEmpty && !value) return '';
    if (/^\d+$/.test(value)) return value;
    console.log('✗ يجب أن يكون الرقم مكوّنًا من أرقام فقط.\n');
  }
}

async function main() {
  console.log('╭────────────────────────────────────╮');
  console.log('│              HU TAN                │');
  console.log('│            0.3.0-beta              │');
  console.log('│            المطور: Rin Il          │');
  console.log('╰────────────────────────────────────╯\n');
  console.log('يُحفظ AppState ومفتاح AI محليًا فقط. ضع معرّف المدير والغروب في config/EDIT_ME.json إن رغبت، ولا تضع الأسرار الفعلية في GitHub.\n');

  const editMe = readEditMe();
  let appStatePath;
  try {
    appStatePath = normalizeAppStatePath(editMe.appStatePath);
  } catch (_) {
    appStatePath = 'data/appstate.json';
  }

  const appStateAbsolutePath = path.join(ROOT, appStatePath);
  const appState = await getAppState(appStatePath);

  const presetGroup = /^\d+$/.test(String(editMe.groupID || '')) ? String(editMe.groupID) : '';
  const presetOwner = /^\d+$/.test(String(editMe.adminID || '')) ? String(editMe.adminID) : '';
  const groupID = await askNumeric('ID الغروب المسموح به: ', presetGroup);
  const ownerID = await askNumeric('ID المدير الإداري (اتركه فارغًا للاعتماد على حساب البوت): ', presetOwner, true);

  const presetAI = editMe.ai && typeof editMe.ai === 'object' ? editMe.ai : {};
  const aiURL = String(presetAI.url || '').trim() || await ask('رابط API للذكاء الاصطناعي (Enter للتخطي): ');
  // لا نقرأ مفتاح API من EDIT_ME.json حتى لا يتحول الملف القابل للرفع إلى مخزن أسرار.
  let aiKey = '';
  let aiModel = String(presetAI.model || '');
  if (aiURL) aiKey = await askSecret('مفتاح API (Enter إن لم يوجد): ');
  if (aiURL && !aiModel) aiModel = await ask('اسم النموذج (اختياري): ');

  const welcome = parseYesNo(await ask('تفعيل ترحيب الأعضاء؟ [نعم/لا]: '), true);
  const startupGreeting = parseYesNo(await ask('إرسال رسالة التعريف عند أول تشغيل؟ [نعم/لا]: '), true);

  const config = {
    bot: {
      name: 'Hu Tan',
      developer: 'Rin Il',
      version: '0.3.0-beta',
      language: 'ar',
      prefix: '.',
      feminineSelfReference: true
    },
    facebook: {
      allowedThreadID: groupID,
      ownerID,
      appStateFile: appStatePath,
      listenEvents: true,
      autoReconnect: true,
      autoListen: false,
      selfListen: false,
      selfListenEvent: false,
      listenTyping: false,
      online: false,
      updatePresence: false,
      autoMarkDelivery: false,
      autoMarkRead: true,
      forceLogin: true,
      simulateTyping: false,
      randomUserAgent: false,
      persona: 'desktop',
      stealthMode: true,
      maxConcurrentRequests: 2,
      maxRequestsPerMinute: 60,
      requestCooldownMs: 60000,
      errorCacheTtlMs: 300000,
      mqttReconnectDelayMs: 3000,
      mqttMaxReconnectAttempts: 50,
      logLevel: 'error'
    },
    features: {
      welcome,
      startupGreeting,
      rank: true,
      economy: true,
      tasks: true,
      messageCounter: true,
      antiSpam: true
    },
    limits: {
      commandCooldownMs: 2500,
      maxCommandsPerMinute: 18,
      maxMessagesPer10Seconds: 8,
      duplicateEventTTLms: 30000,
      duplicateContentTTLms: 2500,
      workCooldownMs: 30 * 60 * 1000,
      dailyCooldownMs: 24 * 60 * 60 * 1000,
      replyTTLms: 10 * 60 * 1000,
      adminCacheMs: 30 * 1000,
      unknownCommandCooldownMs: 5000
    },
    ai: {
      enabled: Boolean(aiURL),
      url: aiURL,
      apiKey: aiKey,
      model: aiModel,
      allowEveryoneReply: false,
      temperature: 0.85,
      maxTokens: 500,
      timeoutMs: 30000,
      maxPromptChars: 4000,
      feminineSystemPrompt:
        'أنتِ Hu Tan، بوت أنثى هادئة وطبيعية تتحدث بالعربية. استخدمي صيغة المؤنث عند الحديث عن نفسك فقط، مثل: أنا جاهزة، أستطيع، فعلتُ. عند مخاطبة أي مستخدم، استخدمي صيغة المذكر المفرد المحايدة فقط، مثل: اكتب، لديك، حصلت على، استمر. عند مخاطبة المجموعة استخدمي صيغة الجمع المذكر المحايدة مثل: أهلًا بكم. لا تنسبي الصفات الأنثوية للمستخدم لمجرد مخاطبته، ولا تفترضي جنسه. تحدثي بعفوية واختصار وراعي سياق المحادثة. لا تدّعي تنفيذ شيء لم تنفذيه. لا تذكري التفاصيل التقنية إلا عند السؤال عنها مباشرة.'
    }
  };

  secureWrite(appStateAbsolutePath, appState);
  secureWrite(CONFIG_PATH, config);

  const dbPath = path.join(DATA_DIR, 'database.json');
  if (!fs.existsSync(dbPath)) {
    secureWrite(dbPath, { meta: { version: 3 }, users: {}, thread: {}, transactions: {} });
  }

  console.log('\n✓ تم حفظ AppState محليًا.');
  console.log('✓ تم حفظ إعدادات Hu Tan محليًا.');
  console.log('✓ تم قفل البوت على غروب واحد.');
  console.log(`✓ ملف AppState: ${appStatePath}`);
  console.log('\nشغّل البوت بـ: npm start\n');
  rl.close();
}

main().catch((error) => {
  console.error(`\n✗ فشل الإعداد: ${error.stack || error.message}`);
  try { rl.close(); } catch (_) {}
  process.exit(1);
});
