'use strict';
const { box } = require('../../utils/format');
module.exports = {
  name: 'معلومات_عضو',
  aliases: ['بيانات_عضو'],
  category: 'admin',
  adminOnly: true,
  description: 'عرض بيانات عضو.',
  async execute(ctx) {
    const targetID = ctx.targetUserID() || ctx.userID;
    const target = ctx.db.getUser(targetID);
    await ctx.send(box('بيانات العضو', [
      `الاسم: ${target.name}`,
      `الرسائل: ${target.messages}`,
      `الأوامر: ${target.commands}`,
      `المستوى: ${target.level}`,
      `XP: ${target.xp}`,
      `العملات: ${target.coins}`,
      `البنك: ${target.bank}`,
      `التحذيرات: ${target.warnings}`
    ]));
  }
};
