'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..', '..');
const CONFIG_PATH = path.join(ROOT, 'config', 'config.json');

function positiveNumber(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : fallback;
}

function loadConfig() {
  if (!fs.existsSync(CONFIG_PATH)) {
    throw new Error('config/config.json غير موجود. شغّل npm run setup لإكمال الإعداد.');
  }

  let config;
  try {
    config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8').replace(/^\uFEFF/, ''));
  } catch (error) {
    throw new Error(`config.json غير صالح: ${error.message}`);
  }

  if (!/^\d+$/.test(String(config.facebook?.allowedThreadID || ''))) {
    throw new Error('facebook.allowedThreadID غير صالح.');
  }

  config.bot = {
    name: 'Hu Tan',
    developer: 'Rin Il',
    version: '0.3.0-beta',
    language: 'ar',
    prefix: '.',
    feminineSelfReference: true,
    ...config.bot,
    name: 'Hu Tan',
    developer: 'Rin Il',
    version: '0.3.0-beta',
    language: 'ar',
    prefix: '.',
    feminineSelfReference: true
  };

  config.facebook = {
    listenEvents: true,
    autoReconnect: true,
    autoListen: false,
    selfListen: false,
    selfListenEvent: false,
    listenTyping: false,
    online: false,
    updatePresence: false,
    autoMarkDelivery: false,
    autoMarkRead: true,
    forceLogin: true,
    simulateTyping: false,
    randomUserAgent: false,
    persona: 'desktop',
    stealthMode: true,
    maxConcurrentRequests: 2,
    maxRequestsPerMinute: 60,
    requestCooldownMs: 60000,
    errorCacheTtlMs: 300000,
    mqttReconnectDelayMs: 3000,
    mqttMaxReconnectAttempts: 50,
    logLevel: 'error',
    ownerID: '',
    appStateFile: 'data/appstate.json',
    ...config.facebook,
    allowedThreadID: String(config.facebook.allowedThreadID),
    ownerID: config.facebook.ownerID ? String(config.facebook.ownerID) : '',
    appStateFile: String(config.facebook.appStateFile || 'data/appstate.json')
  };

  const appStateFile = path.normalize(config.facebook.appStateFile);
  if (path.isAbsolute(appStateFile) || appStateFile.startsWith('..') || appStateFile.includes(`..${path.sep}`) || !(appStateFile === 'data/appstate.json' || appStateFile.startsWith(`data${path.sep}`))) {
    throw new Error('facebook.appStateFile يجب أن يكون ملف JSON داخل مجلد data/.');
  }
  config.facebook.appStateFile = appStateFile;

  config.features = {
    welcome: true,
    startupGreeting: true,
    rank: true,
    economy: true,
    tasks: true,
    messageCounter: true,
    antiSpam: true,
    ...config.features
  };

  config.limits = {
    commandCooldownMs: 2500,
    maxCommandsPerMinute: 18,
    maxMessagesPer10Seconds: 8,
    duplicateEventTTLms: 30000,
    duplicateContentTTLms: 2500,
    workCooldownMs: 30 * 60 * 1000,
    dailyCooldownMs: 24 * 60 * 60 * 1000,
    replyTTLms: 10 * 60 * 1000,
    adminCacheMs: 30 * 1000,
    unknownCommandCooldownMs: 5000,
    ...config.limits
  };

  for (const key of Object.keys(config.limits)) {
    config.limits[key] = positiveNumber(config.limits[key], 1);
  }

  config.ai = {
    enabled: Boolean(config.ai?.enabled && config.ai?.url),
    url: '',
    apiKey: '',
    model: '',
    allowEveryoneReply: false,
    temperature: 0.85,
    maxTokens: 500,
    timeoutMs: 30000,
    maxPromptChars: 4000,
    feminineSystemPrompt:
      'أنتِ Hu Tan، بوت أنثى هادئة وطبيعية داخل دردشة جماعية. استخدمي صيغة المؤنث عند الحديث عن نفسك فقط، مثل: أنا جاهزة، أستطيع، فعلتُ. عند مخاطبة أي مستخدم، استخدمي صيغة المذكر المفرد المحايدة فقط، مثل: اكتب، لديك، حصلت على، استمر. عند مخاطبة المجموعة استخدمي صيغة الجمع المذكر المحايدة مثل: أهلًا بكم. لا تنسبي الصفات الأنثوية للمستخدم لمجرد مخاطبته، ولا تفترضي جنسه. تحدثي بعفوية واختصار وراعي سياق المحادثة. لا تدّعي تنفيذ شيء لم تنفذيه. لا تذكري التفاصيل التقنية إلا عند السؤال عنها مباشرة.',
    ...config.ai
  };

  config.ai.url = String(config.ai.url || '').trim();
  config.ai.apiKey = String(config.ai.apiKey || '');
  config.ai.model = String(config.ai.model || '').trim();
  config.ai.maxPromptChars = positiveNumber(config.ai.maxPromptChars, 4000);
  config.ai.maxTokens = positiveNumber(config.ai.maxTokens, 500);
  config.ai.timeoutMs = positiveNumber(config.ai.timeoutMs, 30000);

  return config;
}

module.exports = { ROOT, CONFIG_PATH, loadConfig };
