'use strict';

const path = require('path');
const fs = require('fs');
const { createContext } = require('./context');
const { isAdmin } = require('./permissions');
const { box, msToText } = require('../utils/format');
const logger = require('../utils/logger');

function loadEventHandlers(root) {
  const handlers = [];
  if (!fs.existsSync(root)) return handlers;

  for (const file of fs.readdirSync(root).filter((name) => name.endsWith('.js')).sort()) {
    const full = path.join(root, file);
    delete require.cache[require.resolve(full)];
    const handler = require(full);
    if (typeof handler === 'function') handlers.push({ name: file, handler });
  }

  return handlers;
}

function featureForCategory(category) {
  const map = {
    level: 'rank',
    economy: 'economy',
    tasks: 'tasks',
    ai: 'ai'
  };
  return map[category] || null;
}

class Dispatcher {
  constructor(app) {
    this.app = app;
    this.eventHandlers = loadEventHandlers(path.join(__dirname, '..', 'events'));
    this.processedEvents = new Map();
    this.contentFingerprints = new Map();
  }

  parseCommand(body) {
    const text = String(body || '').trim();
    const prefix = this.app.config.bot.prefix;
    if (!text.startsWith(prefix)) return null;

    const rest = text.slice(prefix.length).trim();
    if (!rest) return null;

    const parts = rest.split(/\s+/);
    const name = String(parts.shift() || '').trim().toLowerCase();
    if (!name) return null;

    return { name, args: parts, raw: rest };
  }

  async safeSend(message, threadID, messageID) {
    try {
      await this.app.send(message, threadID, messageID);
      return true;
    } catch (error) {
      logger.error(`فشل إرسال رسالة: ${error.message}`);
      return false;
    }
  }

  async isAdmin(userID, threadID) {
    return isAdmin(
      this.app.api,
      threadID,
      userID,
      this.app.config.facebook.ownerID,
      Number(this.app.config.limits.adminCacheMs)
    );
  }

  getEventID(event) {
    return String(
      event?.messageID ||
      event?.messageId ||
      event?.eventID ||
      event?.eventId ||
      ''
    ).trim();
  }

  getSenderID(event) {
    return String(event?.senderID || event?.author || event?.senderId || '').trim();
  }

  getEventType(event) {
    return String(event?.type || event?.eventType || '').trim().toLowerCase();
  }

  shouldProcessEvent(event) {
    const now = Date.now();
    const eventTTL = Number(this.app.config.limits.duplicateEventTTLms || 30000);
    const contentTTL = Number(this.app.config.limits.duplicateContentTTLms || 2500);
    const type = this.getEventType(event);
    const senderID = this.getSenderID(event);
    const botID = String(this.app.botID || '').trim();

    if (event?.isSelf === true || event?.isFromSelf === true) return false;
    if (botID && senderID && senderID === botID) return false;

    const eventID = this.getEventID(event);
    if (eventID) {
      const key = `id:${eventID}`;
      const previous = this.processedEvents.get(key);
      if (previous && now - previous < eventTTL) return false;
      this.processedEvents.set(key, now);
      return true;
    }

    // بعض إصدارات MQTT لا تضع messageID في الحدث. نستخدم بصمة المحتوى
    // نفسها لجميع أحداث النص لمنع تمرير الرسالة نفسها مرتين بأسماء أحداث مختلفة.
    if (senderID) {
      const body = String(event?.body || '').trim();
      const threadID = String(event?.threadID || '').trim();
      let signature = '';

      if (body) {
        signature = `message:${senderID}:${threadID}:${body}`;
      } else if (type) {
        const subtype = String(event?.logMessageType || event?.subtype || '').trim();
        const participants = Array.isArray(event?.logMessageData?.addedParticipants)
          ? event.logMessageData.addedParticipants.map((item) => String(item?.userFbId || item?.userId || item?.id || '')).filter(Boolean).sort().join(',')
          : '';
        signature = `event:${senderID}:${threadID}:${type}:${subtype}:${participants}`;
      }

      if (signature) {
        const previous = this.contentFingerprints.get(signature);
        if (previous && now - previous < contentTTL) return false;
        this.contentFingerprints.set(signature, now);
      }
    }

    return true;
  }

  cleanup() {
    const now = Date.now();
    const eventTTL = Number(this.app.config.limits.duplicateEventTTLms || 30000);
    const contentTTL = Number(this.app.config.limits.duplicateContentTTLms || 2500);

    for (const [key, time] of this.processedEvents) {
      if (now - time >= eventTTL) this.processedEvents.delete(key);
    }

    for (const [key, time] of this.contentFingerprints) {
      if (now - time >= contentTTL * 2) this.contentFingerprints.delete(key);
    }

    if (this.processedEvents.size > 2000) {
      const entries = [...this.processedEvents.entries()].sort((a, b) => a[1] - b[1]);
      for (const [key] of entries.slice(0, entries.length - 1500)) this.processedEvents.delete(key);
    }

    if (this.contentFingerprints.size > 1000) {
      const entries = [...this.contentFingerprints.entries()].sort((a, b) => a[1] - b[1]);
      for (const [key] of entries.slice(0, entries.length - 750)) this.contentFingerprints.delete(key);
    }
  }

  async runCommand(event, parsed, options = {}) {
    const command = this.app.commandManager.get(parsed.name);
    if (!command) {
      if (this.app.limiter.unknownAllowed(event.senderID)) {
        await this.safeSend(
          box('Hu Tan', [
            `الأمر «${parsed.name}» غير موجود.`,
            `اكتب ${this.app.config.bot.prefix}القائمة لرؤية الأوامر.`
          ]),
          event.threadID
        );
      }
      return true;
    }

    const thread = this.app.db.getThread();
    if (!options.fromReply && thread.quiet && command.category !== 'admin' && command.name !== 'وضع_الهدوء') return true;

    const feature = featureForCategory(command.category);
    if (feature && this.app.config.features[feature] === false) {
      await this.safeSend(`قسم «${command.category}» متوقف حاليًا.`, event.threadID);
      return true;
    }

    const rate = this.app.limiter.commandAllowed(event.senderID);
    if (!rate.ok) {
      await this.safeSend(`⏳ تمهل قليلًا، عد بعد ${msToText(rate.retryAfter)}.`, event.threadID);
      return true;
    }

    const user = this.app.db.getUser(event.senderID);
    this.app.db.touchCommand(user);
    thread.totalCommands += 1;
    this.app.db.scheduleSave();

    const ctx = createContext(this.app, event, parsed.name, parsed.args);
    try {
      if (command.adminOnly) await ctx.requireAdmin();
      await command.execute(ctx, options);
    } catch (error) {
      logger.error(`الأمر .${command.name}: ${error.stack || error.message}`);
      await this.safeSend(`تعذر تنفيذ .${command.name}.\n${error.message}`, event.threadID);
    }

    return true;
  }

  async process(event) {
    if (!event) return;

    const threadID = String(event.threadID || '');
    if (threadID !== String(this.app.config.facebook.allowedThreadID)) return;

    if (!this.shouldProcessEvent(event)) return;

    for (const { handler } of this.eventHandlers) {
      try {
        const handled = await handler(this.app, event, this);
        if (handled === true) return;
      } catch (error) {
        logger.error(`حدث ${event.type || event.eventType || 'غير معروف'}: ${error.stack || error.message}`);
      }
    }
  }
}

module.exports = Dispatcher;
