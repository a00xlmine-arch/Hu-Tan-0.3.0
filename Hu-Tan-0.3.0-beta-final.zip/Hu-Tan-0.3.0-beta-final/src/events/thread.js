'use strict';

const { box, cleanName } = require('../utils/format');

function extractParticipants(event) {
  const data = event.logMessageData || {};
  const raw = Array.isArray(data.addedParticipants)
    ? data.addedParticipants
    : Array.isArray(data.participants)
      ? data.participants
      : [];

  return raw.map((item) => ({
    id: String(item.userFbId || item.userId || item.id || ''),
    name: cleanName(item.fullName || item.name || item.firstName, 'عضو')
  })).filter((item) => item.id);
}

module.exports = async function threadEvent(app, event, dispatcher) {
  const type = String(event?.type || event?.eventType || '').toLowerCase();
  if (type !== 'event') return false;

  const subtype = String(event.logMessageType || event.subtype || event.eventType || '');
  if (!['log:subscribe', 'participantAdded', 'subscribe'].includes(subtype)) return false;

  const thread = app.db.getThread();
  if (!thread.welcome) return true;

  const participants = extractParticipants(event);
  const botID = String(app.botID || '');
  const human = participants.filter((person) => !botID || person.id !== botID);
  if (!human.length) return true;

  for (const person of human) {
    const user = app.db.getUser(person.id);
    user.name = person.name;
  }
  app.db.scheduleSave();

  const names = human.map((person) => person.name).join('، ');
  await dispatcher.safeSend(
    box('أهلًا بك', [
      `${names}، نورت الغروب.`,
      'أنا Hu Tan، سعيدة بانضمامك معنا.',
      `اكتب ${app.config.bot.prefix}القائمة لرؤية ما أستطيع فعله.`,
      'المطور: Rin Il'
    ]),
    event.threadID
  );

  return true;
};
